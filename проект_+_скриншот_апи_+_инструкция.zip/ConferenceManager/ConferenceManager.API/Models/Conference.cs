﻿using System.ComponentModel.DataAnnotations;

namespace ConferenceManager.API.Models;

public class Conference
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Название конференции обязательно")]
    [MaxLength(200)]
    public string Name { get; set; }

    [Required(ErrorMessage = "Статус конференции обязателен")]
    public ConferenceStatus Status { get; set; }

    [Required(ErrorMessage = "Дата проведения обязательна")]
    public DateTime Date { get; set; }

    [Required(ErrorMessage = "Место проведения обязательно")]
    [MaxLength(100)]
    public string Location { get; set; }

    [MaxLength(500)] public string Topics { get; set; }

    [MaxLength(200)] public string Organizer { get; set; }

    public List<Committee> Committees { get; set; } = new();
    public List<Participant> Participants { get; set; } = new();
}

public enum ConferenceStatus
{
    Planned,
    InProgress,
    Completed
}