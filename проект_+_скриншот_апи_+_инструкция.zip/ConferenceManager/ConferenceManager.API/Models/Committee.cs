﻿using System.ComponentModel.DataAnnotations;

namespace ConferenceManager.API.Models;

public class Committee
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Тип комитета обязателен")]
    public CommitteeType Type { get; set; }

    public int ConferenceId { get; set; }
    public Conference Conference { get; set; }

    public List<CommitteeMember> Members { get; set; } = new();
}

public enum CommitteeType
{
    Organizing,
    Program
}

public class CommitteeMember
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Имя члена комитета обязательно")]
    [MaxLength(100)]
    public string Name { get; set; }

    [MaxLength(100)] public string Position { get; set; }

    public int CommitteeId { get; set; }
    public Committee Committee { get; set; }
}