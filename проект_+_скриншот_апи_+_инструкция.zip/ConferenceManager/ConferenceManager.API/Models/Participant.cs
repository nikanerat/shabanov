﻿using System.ComponentModel.DataAnnotations;

namespace ConferenceManager.API.Models;

public class Participant
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Имя участника обязательно")]
    [MaxLength(100)]
    public string Name { get; set; }

    [Required(ErrorMessage = "Email обязателен")]
    [EmailAddress(ErrorMessage = "Некорректный email")]
    [MaxLength(100)]
    public string Email { get; set; }

    [Phone(ErrorMessage = "Некорректный номер телефона")]
    [MaxLength(20)]
    public string Phone { get; set; }

    [Required(ErrorMessage = "Статус участия обязателен")]
    public ParticipationStatus Status { get; set; }

    public int ConferenceId { get; set; }
    public Conference Conference { get; set; }
}

public enum ParticipationStatus
{
    Pending,
    Confirmed
}