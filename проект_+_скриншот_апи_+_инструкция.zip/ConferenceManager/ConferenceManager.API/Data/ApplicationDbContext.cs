﻿using ConferenceManager.API.Models;
using Microsoft.EntityFrameworkCore;

namespace ConferenceManager.API.Data;

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
    {
    }

    public DbSet<Conference> Conferences { get; set; }
    public DbSet<Committee> Committees { get; set; }
    public DbSet<CommitteeMember> CommitteeMembers { get; set; }
    public DbSet<Participant> Participants { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Conference>()
            .HasMany(c => c.Committees)
            .WithOne(c => c.Conference)
            .HasForeignKey(c => c.ConferenceId)
            .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<Conference>()
            .HasMany(c => c.Participants)
            .WithOne(p => p.Conference)
            .HasForeignKey(p => p.ConferenceId)
            .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<Committee>()
            .HasMany(c => c.Members)
            .WithOne(m => m.Committee)
            .HasForeignKey(m => m.CommitteeId)
            .OnDelete(DeleteBehavior.Cascade);
    }
}