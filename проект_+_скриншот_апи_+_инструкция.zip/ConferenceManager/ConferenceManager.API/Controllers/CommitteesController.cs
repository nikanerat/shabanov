﻿using ConferenceManager.API.Data;
using ConferenceManager.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ConferenceManager.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CommitteesController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public CommitteesController(ApplicationDbContext context)
    {
        _context = context;
    }

    [HttpGet("conference/{conferenceId}")]
    public async Task<ActionResult<IEnumerable<Committee>>> GetCommittees(int conferenceId)
    {
        return await _context.Committees
            .Include(c => c.Members)
            .Where(c => c.ConferenceId == conferenceId)
            .ToListAsync();
    }

    [HttpPost]
    public async Task<ActionResult<Committee>> CreateCommittee(Committee committee)
    {
        _context.Committees.Add(committee);
        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(GetCommittee), new { id = committee.Id }, committee);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<Committee>> GetCommittee(int id)
    {
        var committee = await _context.Committees
            .Include(c => c.Members)
            .FirstOrDefaultAsync(c => c.Id == id);

        if (committee == null) return NotFound();

        return committee;
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateCommittee(int id, Committee committee)
    {
        if (id != committee.Id) return BadRequest();

        _context.Entry(committee).State = EntityState.Modified;

        try
        {
            await _context.SaveChangesAsync();
        }
        catch (DbUpdateConcurrencyException)
        {
            if (!CommitteeExists(id)) return NotFound();
            throw;
        }

        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteCommittee(int id)
    {
        var committee = await _context.Committees.FindAsync(id);
        if (committee == null) return NotFound();

        _context.Committees.Remove(committee);
        await _context.SaveChangesAsync();

        return NoContent();
    }

    private bool CommitteeExists(int id)
    {
        return _context.Committees.Any(e => e.Id == id);
    }
}