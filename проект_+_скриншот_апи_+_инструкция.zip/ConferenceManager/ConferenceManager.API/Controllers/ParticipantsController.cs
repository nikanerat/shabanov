﻿using ConferenceManager.API.Data;
using ConferenceManager.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ConferenceManager.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ParticipantsController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public ParticipantsController(ApplicationDbContext context)
    {
        _context = context;
    }

    [HttpGet("conference/{conferenceId}")]
    public async Task<ActionResult<IEnumerable<Participant>>> GetParticipants(
        int conferenceId,
        string searchTerm = null,
        ParticipationStatus? status = null)
    {
        var query = _context.Participants
            .Where(p => p.ConferenceId == conferenceId);

        if (!string.IsNullOrEmpty(searchTerm))
            query = query.Where(p =>
                p.Name.Contains(searchTerm) ||
                p.Email.Contains(searchTerm));

        if (status.HasValue) query = query.Where(p => p.Status == status);

        return await query.ToListAsync();
    }

    [HttpPost]
    public async Task<ActionResult<Participant>> CreateParticipant(Participant participant)
    {
        _context.Participants.Add(participant);
        await _context.SaveChangesAsync();
        return CreatedAtAction(nameof(GetParticipant), new { id = participant.Id }, participant);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<Participant>> GetParticipant(int id)
    {
        var participant = await _context.Participants.FindAsync(id);
        if (participant == null) return NotFound();
        return participant;
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateParticipant(int id, Participant participant)
    {
        if (id != participant.Id) return BadRequest();
        _context.Entry(participant).State = EntityState.Modified;
        await _context.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteParticipant(int id)
    {
        var participant = await _context.Participants.FindAsync(id);
        if (participant == null) return NotFound();
        _context.Participants.Remove(participant);
        await _context.SaveChangesAsync();
        return NoContent();
    }
}