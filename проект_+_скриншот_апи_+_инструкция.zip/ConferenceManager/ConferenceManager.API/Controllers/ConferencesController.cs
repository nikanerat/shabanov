﻿using ConferenceManager.API.Data;
using ConferenceManager.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ConferenceManager.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ConferencesController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public ConferencesController(ApplicationDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<Conference>>> GetConferences(
        string searchTerm = null,
        ConferenceStatus? status = null,
        string sortBy = null)
    {
        var query = _context.Conferences
            .Include(c => c.Committees)
            .ThenInclude(c => c.Members)
            .Include(c => c.Participants)
            .AsQueryable();

        if (!string.IsNullOrEmpty(searchTerm))
            query = query.Where(c =>
                c.Name.Contains(searchTerm) ||
                c.Location.Contains(searchTerm));

        if (status.HasValue) query = query.Where(c => c.Status == status);

        query = sortBy?.ToLower() switch
        {
            "date" => query.OrderBy(c => c.Date),
            "name" => query.OrderBy(c => c.Name),
            "status" => query.OrderBy(c => c.Status),
            _ => query.OrderBy(c => c.Date)
        };

        return await query.ToListAsync();
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<Conference>> GetConference(int id)
    {
        var conference = await _context.Conferences
            .Include(c => c.Committees)
            .ThenInclude(c => c.Members)
            .Include(c => c.Participants)
            .FirstOrDefaultAsync(c => c.Id == id);

        if (conference == null) return NotFound();

        return conference;
    }

    [HttpPost]
    public async Task<ActionResult<Conference>> CreateConference(Conference conference)
    {
        _context.Conferences.Add(conference);
        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(GetConference), new { id = conference.Id }, conference);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateConference(int id, Conference conference)
    {
        if (id != conference.Id) return BadRequest();

        _context.Entry(conference).State = EntityState.Modified;

        try
        {
            await _context.SaveChangesAsync();
        }
        catch (DbUpdateConcurrencyException)
        {
            if (!ConferenceExists(id)) return NotFound();
            throw;
        }

        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteConference(int id)
    {
        var conference = await _context.Conferences.FindAsync(id);
        if (conference == null) return NotFound();

        _context.Conferences.Remove(conference);
        await _context.SaveChangesAsync();

        return NoContent();
    }

    private bool ConferenceExists(int id)
    {
        return _context.Conferences.Any(e => e.Id == id);
    }
}