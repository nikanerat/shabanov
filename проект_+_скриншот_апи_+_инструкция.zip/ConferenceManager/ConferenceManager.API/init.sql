﻿CREATE
DATABASE ConferenceManager;
GO

USE ConferenceManager;
GO

CREATE TABLE Conferences
(
    Id        INT IDENTITY(1,1) PRIMARY KEY,
    Name      NVARCHAR(200) NOT NULL,
    Status    INT      NOT NULL,
    Date      DATETIME NOT NULL,
    Location  NVARCHAR(100) NOT NULL,
    Topics    NVARCHAR(500),
    Organizer NVARCHAR(200)
);
GO

CREATE TABLE Committees
(
    Id           INT IDENTITY(1,1) PRIMARY KEY,
    Type         INT NOT NULL,
    ConferenceId INT NOT NULL,
    FOREIGN KEY (ConferenceId) REFERENCES Conferences (Id) ON DELETE CASCADE
);
GO

CREATE TABLE CommitteeMembers
(
    Id          INT IDENTITY(1,1) PRIMARY KEY,
    Name        NVARCHAR(100) NOT NULL,
    Position    NVARCHAR(100),
    CommitteeId INT NOT NULL,
    FOREIGN KEY (CommitteeId) REFERENCES Committees (Id) ON DELETE CASCADE
);
GO

CREATE TABLE Participants
(
    Id           INT IDENTITY(1,1) PRIMARY KEY,
    Name         NVARCHAR(100) NOT NULL,
    Email        NVARCHAR(100) NOT NULL,
    Phone        NVARCHAR(20),
    Status       INT NOT NULL,
    ConferenceId INT NOT NULL,
    FOREIGN KEY (ConferenceId) REFERENCES Conferences (Id) ON DELETE CASCADE
);
GO

INSERT INTO Conferences (Name, Status, Date, Location, Topics, Organizer) VALUES
    ('LXVI Международная научно-практическая конференция «Российская наука в современном мире»', 0, '2024-11-30', 'Москва, Россия', 'Естественные и технические науки, педагогика, экономика, юриспруденция', 'Научно-издательский центр «Актуальность.РФ»'),
    ('V Международная научно-практическая конференция «Актуальные и перспективные научные исследования»', 0, '2024-11-30', 'Пенза, Россия', 'Медицина, психология, технические науки, филология, экономика, юриспруденция', 'МЦНС «Наука и Просвещение»'),
    ('VIII Международная научная конференция по междисциплинарным исследованиям (SDE-IR IV 2024)', 0, '2024-12-17', 'Екатеринбург, Россия', 'Археология, гуманитарные науки, информационные технологии, менеджмент, сельское хозяйство, экономика', 'Институт цифровой экономики и права (ИЦЭиП)'),
    ('Актуальные проблемы инфотелекоммуникаций в науке и образовании (АПИНО)', 2, '2024-02-27', 'Санкт-Петербург, Россия', 'Инфокоммуникационные сети и системы, информационные технологии, цифровая экономика', 'СПбГУТ им. проф. М. А. Бонч-Бруевича'),
    ('XV Международная конференция исследователей высшего образования', 0, '2024-10-23', 'Москва, Россия', 'Высшее образование', 'НИУ ВШЭ');
GO
